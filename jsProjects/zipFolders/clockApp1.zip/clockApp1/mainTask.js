import List from "./timerScript.js"

if (".List") {
    new List(
        document.querySelector(".List")
    )
}